"use client";

import React, { useState } from "react";
import {
  Server,
  Cloud,
  CheckCircle2,
  Copy,
  Check,
  ExternalLink,
  Terminal,
  Globe,
  Database,
  ArrowRight,
  Sparkles,
  Zap,
  HelpCircle,
  AlertTriangle,
} from "lucide-react";

interface DeployGuideViewProps {
  onBack: () => void;
  whatsappPhone?: string;
}

export function DeployGuideView({ onBack, whatsappPhone = "+964 773 387 8591" }: DeployGuideViewProps) {
  const [selectedMethod, setSelectedMethod] = useState<"vercel" | "render" | "vps">("vercel");
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#0b0e14] text-white">
      {/* Header */}
      <div className="px-4 py-3 bg-[#111622] border-b border-gray-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-gray-800 transition-colors"
            title="رجوع"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold text-gray-100">الحصول على رابط دائم ثابت (24/7)</h1>
            <p className="text-[11px] text-emerald-400 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>بدون انتهاء جلسة وبدون صندوق رمل</span>
            </p>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-2xl mx-auto w-full pb-20 text-right">
        {/* Why sandbox expired explanation */}
        <div className="p-4 rounded-3xl bg-amber-950/40 border border-amber-800/60 shadow-lg text-xs space-y-2">
          <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <span>لماذا تظهر رسالة &quot;لم يتم العثور على صندوق الرمل&quot;؟</span>
          </div>
          <p className="text-gray-300 leading-relaxed">
            المنصة الحالية مخصصة لبيئة <strong>البرمجة والتطوير السحابي المؤقتة (Sandbox)</strong>. عندما تغلق الصفحة أو تمضي فترة بدون استخدام، ينتهي الصندوق وتتغير رابطه.
          </p>
          <p className="text-emerald-300 font-semibold leading-relaxed">
            لذلك تم تجهيز كود تطبيق ARES Chat بالكامل ليعمل برابط دائم ومجاني بنسبة 100% على منصات الاستضافة العالمية مثل Vercel أو Render أو أي سيرفر خاص بك.
          </p>
        </div>

        {/* Platform Selector Tabs */}
        <div className="flex items-center gap-2 p-1 bg-[#161c28] rounded-2xl text-xs">
          <button
            onClick={() => setSelectedMethod("vercel")}
            className={`flex-1 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-1.5 ${
              selectedMethod === "vercel"
                ? "bg-blue-600 text-white shadow-md shadow-blue-600/30"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <Cloud className="w-4 h-4" />
            <span>Vercel (الأسرع مجاناً)</span>
          </button>
          <button
            onClick={() => setSelectedMethod("render")}
            className={`flex-1 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-1.5 ${
              selectedMethod === "render"
                ? "bg-purple-600 text-white shadow-md shadow-purple-600/30"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>Render</span>
          </button>
          <button
            onClick={() => setSelectedMethod("vps")}
            className={`flex-1 py-2.5 rounded-xl font-bold transition-all flex items-center justify-center gap-1.5 ${
              selectedMethod === "vps"
                ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <Server className="w-4 h-4" />
            <span>سيرفر VPS خاص</span>
          </button>
        </div>

        {/* Tab 1: Vercel */}
        {selectedMethod === "vercel" && (
          <div className="bg-[#141926] border border-gray-800 rounded-3xl p-5 shadow-xl space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">1</span>
                <span>الرفع على Vercel (رابط رسمي دائم مدى الحياة مجاناً)</span>
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
                موصى به
              </span>
            </div>

            <ol className="list-decimal list-inside space-y-2.5 text-gray-300 leading-relaxed pr-1">
              <li>
                قم بتحميل ملفات المشروع إلى جهازك (زر <strong className="text-white">Download Code / Export ZIP</strong> في المنصة).
              </li>
              <li>
                افتح موقع <a href="https://github.com" target="_blank" rel="noreferrer" className="text-blue-400 underline font-mono">github.com</a> وارفع المجلد في مستودع جديد (Repository) باسم <code className="text-purple-300">ares-chat</code>.
              </li>
              <li>
                ادخل على <a href="https://vercel.com" target="_blank" rel="noreferrer" className="text-blue-400 underline font-mono">vercel.com</a> وسجل بحساب GitHub.
              </li>
              <li>
                اضغط على زر <strong className="text-emerald-400">&quot;Add New Project&quot;</strong> ثم اضغط <strong className="text-emerald-400">&quot;Import&quot;</strong> بجانب مشروع ares-chat.
              </li>
              <li>
                في خانة المتغيرات البيئية (Environment Variables) أضف:
                <div className="mt-1.5 p-2.5 rounded-xl bg-[#1b2232] border border-gray-700 font-mono text-[11px] text-cyan-300 flex items-center justify-between">
                  <span>DATABASE_URL = رابط_قاعدة_البيانات</span>
                  <button
                    onClick={() => handleCopy("DATABASE_URL", "db_var")}
                    className="p-1 hover:text-white text-gray-400"
                  >
                    {copiedText === "db_var" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <span className="text-[10px] text-gray-400 block mt-1">
                  (يمكنك الحصول على قاعدة PostgreSQL مجانية فورية من موقع <a href="https://neon.tech" target="_blank" rel="noreferrer" className="text-blue-400 underline">Neon.tech</a> أو <a href="https://supabase.com" target="_blank" rel="noreferrer" className="text-blue-400 underline">Supabase.com</a>).
                </span>
              </li>
              <li>
                اضغط <strong className="text-blue-400">&quot;Deploy&quot;</strong> وسيظهر لك رابط رسمي فوري لا ينتهي أبداً:
                <div className="mt-1 p-2 rounded-xl bg-emerald-950/60 border border-emerald-800 font-mono text-emerald-300 text-center font-bold">
                  https://ares-chat-production.vercel.app
                </div>
              </li>
            </ol>
          </div>
        )}

        {/* Tab 2: Render */}
        {selectedMethod === "render" && (
          <div className="bg-[#141926] border border-gray-800 rounded-3xl p-5 shadow-xl space-y-4 text-xs">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center text-xs">2</span>
              <span>الرفع على Render (سيرفر وقاعدة بيانات مدمجة)</span>
            </h2>

            <ol className="list-decimal list-inside space-y-2 text-gray-300 leading-relaxed pr-1">
              <li>افتح موقع <a href="https://render.com" target="_blank" rel="noreferrer" className="text-purple-400 underline font-mono">render.com</a> وأنشئ حساباً مجانياً.</li>
              <li>اختر <strong className="text-white">&quot;New Web Service&quot;</strong> واربطه مع كود GitHub الخاص بك.</li>
              <li>في حقل Build Command اكتب: <code className="text-cyan-300 font-mono">npm run build</code></li>
              <li>في حقل Start Command اكتب: <code className="text-cyan-300 font-mono">npm run start</code></li>
              <li>سيعطيك Render رابط دائم مثل: <code className="text-emerald-300 font-mono">https://ares-chat.onrender.com</code></li>
            </ol>
          </div>
        )}

        {/* Tab 3: VPS */}
        {selectedMethod === "vps" && (
          <div className="bg-[#141926] border border-gray-800 rounded-3xl p-5 shadow-xl space-y-4 text-xs">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs">3</span>
              <span>التشغيل على سيرفرك الخاص (VPS أو لابتوبك الشخصي 24/7)</span>
            </h2>

            <div className="space-y-2">
              <span className="text-gray-400 block">أوامر التشغيل المباشرة في السيرفر:</span>
              <div className="p-3 bg-[#0a0d14] rounded-2xl border border-gray-800 font-mono text-cyan-300 text-left space-y-1.5" dir="ltr">
                <div className="flex justify-between items-center text-gray-400 border-b border-gray-800 pb-1">
                  <span>Bash Commands</span>
                  <button
                    onClick={() => handleCopy("npm install && npm run build && npx pm2 start npm --name 'ares-chat' -- start", "cmd_vps")}
                    className="p-1 hover:text-white"
                  >
                    {copiedText === "cmd_vps" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p>npm install</p>
                <p>npm run build</p>
                <p>npm install -g pm2</p>
                <p>pm2 start npm --name &quot;ares-chat&quot; -- start</p>
                <p>pm2 save</p>
              </div>
              <p className="text-gray-400 text-[11px] pt-1">
                بهذه الأوامر، سيعمل التطبيق في الخلفية بصورة دائمة حتى لو أغلقت نافذة الأوامر، ولن يتوقف أبداً.
              </p>
            </div>
          </div>
        )}

        {/* WhatsApp & API Credentials to connect to the permanent URL */}
        <div className="bg-[#141926] border border-emerald-900/40 rounded-3xl p-5 shadow-lg space-y-3 text-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>البيانات الثابتة المجهزة في السيرفر:</span>
            </h3>
            <span className="text-[10px] text-emerald-400 font-mono font-bold" dir="ltr">
              {whatsappPhone}
            </span>
          </div>

          <div className="p-3 bg-[#1b2232] rounded-2xl border border-gray-700/80 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">رقم الواتساب:</span>
              <span className="font-mono text-white font-bold" dir="ltr">{whatsappPhone}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">مفتاح الـ API:</span>
              <span className="font-mono text-purple-300 font-bold" dir="ltr">ares_live_sec_9942a7810df</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">مسار الـ Webhook:</span>
              <span className="font-mono text-cyan-300 font-bold" dir="ltr">/api/webhook</span>
            </div>
          </div>
        </div>

        {/* Back button */}
        <button
          onClick={onBack}
          className="w-full py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition-all"
        >
          العودة للمحادثات الرئيسية
        </button>
      </div>
    </div>
  );
}
